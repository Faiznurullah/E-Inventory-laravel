
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12"> 
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-success">Edit Data</h6>
        </div>
        <div class="card-body">
           
            <form action="/updatedatabarang/<?php echo e($databarang->id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

   <div class="row">

       <div class="col-md-6">
        <label for="exampleFormControlInput1" class="form-label">Nama Data Barang:</label>
        <input type="text" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> is-valid" value="<?php echo e($databarang->name); ?>" name="name" id="exampleFormControlInput1" placeholder="Jenis Barang Contoh:Kursi">
        <div class="valid-feedback">
          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
     <div class="alert alert-danger"><?php echo e($message); ?></div>
       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
       </div>

       <div class="col-md-6">
        <div class="form-group">
            <label for="exampleFormControlSelect1">Jenis Data Barang</label>
            <select class="form-control" id="exampleFormControlSelect1" name="jenis_barang">
                <?php $__currentLoopData = $jenisbarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($row->name); ?>"><?php echo e($row->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="valid-feedback">
            <?php $__errorArgs = ['jenis_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
       <div class="alert alert-danger"><?php echo e($message); ?></div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
       </div>
       
   </div>


   <div class="row">

    <div class="col-md-6">
    <label for="exampleFormControlSelect1">Foto Data Barang</label>
   <div class="custom-file">
    <input type="file" class="custom-file-input" id="customFile" name="foto">
    <label class="custom-file-label" for="customFile">Choose file</label>
  </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="exampleFormControlSelect1">Kondisi Data Barang</label>
            <select class="form-control" id="exampleFormControlSelect1" name="kondisi">
              <option value="baik">Baik</option>
              <option value="rusak">Rusak</option>
            </select>
          </div>
        
    </div>
   </div>

   <div class="row">
      <div class="col-md-6">
        <div class="form-group">
            <label for="exampleFormControlSelect1">Ketersediaan Data Barang</label>
            <select class="form-control" id="exampleFormControlSelect1" name="tersedia">
              <option value="ya">Tersedia</option>
              <option value="tidak">Tidak Tersedia</option>
            </select>
          </div>
      </div>

   </div>

   <div class="row">
    <div class="col-md-6">
        <div class="d-grid gap-2 mt-4">
            <button class="btn btn-success" type="submit">Kirim Data</button>
          </div>
       </div>
   </div>

            </form>

  </div>
</div>
</div>
</div>

</div>
                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel-2\app-breeze\resources\views/dashboard/databarang/edit.blade.php ENDPATH**/ ?>