
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12"> 
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-success">Tambah Barang Rusak</h6>
        </div>
        <div class="card-body" style="height: 200px;">

            <form action="/insertbarangrusak" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
           
            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Data Barang</label>
                        <select class="form-control" id="exampleFormControlSelect1" name="kode_barang">
                            <?php $__currentLoopData = $databarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($row->kode_barang); ?>"><?php echo e($row->name); ?> | <?php echo e($row->kode_barang); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <div class="valid-feedback">
                        <?php $__errorArgs = ['kode_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger"><?php echo e($message); ?></div>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                   </div>

            </div>

            <div class="row">

                <div class="col-md-6">
                    <div class="d-grid gap-2 mt-4">
                        <button class="btn btn-success" type="submit">Kirim Data</button>
                      </div>
                </div>

            </div>

        </form>

  </div>
</div>
</div>
</div>

</div>
                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel-2\app-breeze\resources\views/dashboard/kerusakan/tambah.blade.php ENDPATH**/ ?>