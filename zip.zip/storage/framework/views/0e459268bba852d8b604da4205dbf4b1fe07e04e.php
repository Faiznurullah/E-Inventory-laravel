
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12"> 
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-success">Data Barang Rusak</h6>
        </div>
        <div class="card-body">
       
            <?php if(session('Pesan')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('Pesan')); ?>.
             </div>  
            <?php endif; ?>

            <div class="row mb-3">
                <div class="col-md-6">
                    <?php if(Auth::user()->kelas == 'admin'): ?>
                    <a href="/downloadpdfbarangrusak" class="d-none d-sm-inline-block btn btn-sm btn-danger shadow-sm"><i
                        class="fas fa-download fa-sm text-white-50"></i> Download PDF</a>
                            <?php elseif(Auth::user()->kelas == 'user'): ?>
                             
                            <?php endif; ?>
            
            </div>
        </div>


            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Barang</th>
                            <th>Jenis Barang</th>
                            <th>Kondis</th>
                            <th>Kode Barang</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>          
                      <?php $__currentLoopData = $kerusakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->name); ?></td>
                            <td><?php echo e($row->jenis_barang); ?></td>
                            <td><?php echo e($row->kondisi); ?></td>
                            <td><?php echo e($row->kode_barang); ?></td>
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>

     

  </div>
</div>
</div>
</div>

</div>
                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel-2\app-breeze\resources\views/dashboard/kerusakan/data.blade.php ENDPATH**/ ?>