
<?php $__env->startSection('content'); ?>

<div class="container">

   <div class="row">
       <div class="col-md-12">
 <!-- Illustrations -->
 <div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-success">Data Peminjaman</h6>
    </div>
    <div class="card-body">
       
        <?php if(session('Pesan')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('Pesan')); ?>.
         </div>  
        <?php endif; ?>


        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Barang</th>
                        <th>Kode Barang</th>
                        <th>Surat/Foto</th>
                        <th>Situasi</th>
                        <th>Verifikasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>          
                  <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($row->name); ?> (<?php echo e($row->peminjam); ?>-<?php echo e($row->name_id); ?>)</td>
                        <td><?php echo e($row->kode_barang); ?></td>
                        <td><center>
                            <?php if($row->tersedia == 'ya'): ?>

                            <a href= "<?php echo e(asset('/surat-peminjaman/'.$row->surat)); ?>" class="btn btn-success btn-sm" target="_blank">Lihat surat</a>

                            <?php elseif($row->tersedia == 'tidak'): ?>
                           
                            <a href= "<?php echo e(asset('/surat-peminjaman/'.$row->surat)); ?>" class="btn btn-success btn-sm" target="_blank">Lihat surat</a>


                           <?php elseif($row->tersedia == 'kembali'): ?>
                           
                           <a href = "<?php echo e(asset('/foto-kembali/'.$row->foto)); ?>" class="btn btn-success btn-sm" target="_blank"> 
                             Lihat foto
                            </a>
                       
                           <?php elseif($row->tersedia == 'selesai'): ?>

                           Proses Selesai

                          <?php endif; ?>
                        </center></td>
                        <td>
                            <?php if($row->tersedia == 'ya'): ?>

                            Proses Verifikasi

                            <?php elseif($row->tersedia == 'tidak'): ?>
                           
                           Boleh Dipinjam

                           <?php elseif($row->tersedia == 'kembali'): ?>

                           Proses Pengembalian

                           <?php elseif($row->tersedia == 'selesai'): ?>

                           Proses Selesai

                          <?php endif; ?>
                        </td>
                        <td>
                            <?php if(Auth::user()->kelas == 'admin'): ?>

                               <?php if($row->tersedia === 'ya'): ?>

                               <form action="/verifikasipeminjaman/<?php echo e($row->id); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>                
                                <button class="btn btn-success btn-sm" type="submit">Verifikasi Peminjaman</button>
                               </form>

                               <?php elseif($row->tersedia === 'tidak'): ?>
                                
                                <button class="btn btn-success btn-sm">Sudah Verifikasi</button>

                                  
                               <?php elseif($row->tersedia === 'kembali'): ?>

                               <form action="/verifikasipengembalian/<?php echo e($row->id); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>   
                               <button class="btn btn-success btn-sm">Verifikasi Pengembalian</button>
                               </form>

                               <?php elseif($row->tersedia == 'selesai'): ?>

                               <button class="btn btn-success btn-sm">Peminjaman selesai</button>


                               <?php else: ?>

                               <?php endif; ?>



                            <?php elseif( Auth::user()->kelas == 'user' ): ?>

                                 <?php if($row->tersedia == 'ya'): ?>

                                 <button class="btn btn-success btn-sm">Belum Diverifikasi</button>

                                 <?php elseif($row->tersedia == 'tidak'): ?>
                                
                                <button class="btn btn-success btn-sm">Sudah Verifikasi</button>

                                <?php elseif($row->tersedia === 'kembali'): ?>

                                <button class="btn btn-success btn-sm">Belum Verifikasi</button>

                                <?php elseif($row->tersedia === 'selesai'): ?>
                                <button class="btn btn-success btn-sm">Peminjaman Selesai</button>

                               <?php endif; ?>
                      
                            <?php endif; ?>
                          
                        </td>
                    </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
</div>
       </div>
   </div>



</div>
                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel-2\app-breeze\resources\views/dashboard/peminjaman/data.blade.php ENDPATH**/ ?>