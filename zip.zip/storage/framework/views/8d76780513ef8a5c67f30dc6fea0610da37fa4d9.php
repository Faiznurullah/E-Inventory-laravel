<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\belajar-laravel-2\app-breeze\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>